package com.gymsync.app.services;

public abstract class AbstractService {

}
