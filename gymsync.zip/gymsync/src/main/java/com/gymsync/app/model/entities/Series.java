package com.gymsync.app.model.entities;

public class Series {

}
