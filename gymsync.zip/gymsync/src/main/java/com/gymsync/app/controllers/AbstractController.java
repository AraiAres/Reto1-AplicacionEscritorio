package com.gymsync.app.controllers;

public abstract class AbstractController {

}
