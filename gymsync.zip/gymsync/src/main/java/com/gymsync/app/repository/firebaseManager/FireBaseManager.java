package com.gymsync.app.repository.firebaseManager;

import com.gymsync.app.model.entities.User;

public class FireBaseManager {
	
	public void addUser(User user) {
		System.out.println(user.toString());
	}

}
