package com.gymsync.app.controllers;

import java.util.ArrayList;
import java.util.List;

import com.gymsync.app.model.entities.Excercise;
import com.gymsync.app.model.entities.Workout;

public class WorkoutPanelController extends AbstractController {

	public List<Workout> getWorkouts() {

		Workout workout1 = createWorkout("Morning Routine", 3, 1, "https://youtube.com/morning_routine", null);
		Workout workout2 = createWorkout("Evening Stretch", 4, 2, "https://youtube.com/evening_stretch", null);
		Workout workout3 = createWorkout("Evening Stretch", 4, 2, "https://youtube.com/evening_stretch", null);
		Workout workout4 = createWorkout("Evening Stretch", 4, 2, "https://youtube.com/evening_stretch", null);
		Workout workout5 = createWorkout("Evening Stretch", 4, 2, "https://youtube.com/evening_stretch", null);


		ArrayList<Workout> ret = new ArrayList<Workout>();
		ret.add(workout1);
		ret.add(workout2);
		ret.add(workout3);
		ret.add(workout4);
		ret.add(workout5);

		
		return ret;
	}

	public static Workout createWorkout(String name, Integer nExercises, Integer level, String urlVideo,
			List<Excercise> exercises) {
		Workout workout = new Workout();
		workout.setName(name);
		workout.setNExcercises(nExercises);
		workout.setLevel(level);
		workout.setUrlVideo(urlVideo);
		workout.setExcercises(exercises);
		return workout;
	}
}
