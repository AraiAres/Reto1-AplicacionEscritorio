package com.gymsync.app.view.panels;

import javax.swing.BorderFactory;
import javax.swing.JLabel;
import javax.swing.SwingConstants;

import com.gymsync.app.config.UIConfig;
import com.gymsync.app.controllers.ControllerFactory;
import com.gymsync.app.controllers.WorkoutPanelController;
import com.gymsync.app.view.PanelFactory;
import com.gymsync.app.view.customComponents.ProfileButton;
import com.gymsync.app.view.customComponents.WorkoutListPanel;

public class WorkoutPanel extends AbstractPanel {

	private static final long serialVersionUID = -7479444517144905320L;

	private JLabel title = null;
	private ProfileButton profileButton = null;
	private JLabel profileLabel = null;
	private WorkoutListPanel workoutListPanel = null;

	public WorkoutPanel() {
		initialize();
	}

	@Override
	protected void initialize() {

		title = new JLabel("Workouts");
		title.setBounds(450, 30, 300, 70);
		title.setHorizontalAlignment(SwingConstants.CENTER);
		title.setVerticalAlignment(SwingConstants.CENTER);
		title.setForeground(UIConfig.EMIRALD);
		title.setFont(UIConfig.TITLE_FONT);

		profileButton = new ProfileButton(50);
		profileButton.setBounds(1100, 30, 50, 50);
		profileButton.setAlignmentX(CENTER_ALIGNMENT);
		profileButton.addActionListener(e -> {
			switchTProfilePanel();
		});

		profileLabel = new JLabel("Mi Perfil", SwingConstants.CENTER);
		profileLabel.setBounds(1100, 65, 50, 50);
		profileLabel.setFont(UIConfig.LABEL_FONT);
		profileLabel.setAlignmentX(CENTER_ALIGNMENT);

		WorkoutPanelController controller = (WorkoutPanelController) ControllerFactory.getInstance()
				.getController("workoutPanelController");
		workoutListPanel = new WorkoutListPanel(controller.getWorkouts());
		workoutListPanel.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 0, 0));
		workoutListPanel.setBounds(0, 150, 1200, 500);

		add(title);
		add(profileButton);
		add(profileLabel);
		add(workoutListPanel);

	}

	private void switchTProfilePanel() {
		PanelFactory.getInstance().hideAll();
		PanelFactory.getInstance().show("profilePanel");
	}

}
