package com.gymsync.app.controllers;

import java.util.HashMap;

public class ControllerFactory {
	private static ControllerFactory instance = null;
	private HashMap<String, AbstractController> controllers = null;

	public static enum ControllerOptions {
		LOGIN_PANEL_CONTROLLER("loginPanelController"), SIGNUP_PANEL_CONTROLLER("signupPanelController"), WORKOUT_PANEL_CONTROLLER("workoutPanelController");

		public final String value;

		private ControllerOptions(String value) {
			this.value = value;
		}
	}

	public ControllerFactory() {
		controllers = new HashMap<String, AbstractController>();
		controllers.put(ControllerOptions.LOGIN_PANEL_CONTROLLER.value, new LoginPanelController());
		controllers.put(ControllerOptions.SIGNUP_PANEL_CONTROLLER.value, new SignupPanelController());
		controllers.put(ControllerOptions.WORKOUT_PANEL_CONTROLLER.value, new WorkoutPanelController());
	}

	public static ControllerFactory getInstance() {
		return instance = instance == null ? new ControllerFactory() : instance;
	}

	public AbstractController getController(String controllerOption) {
		return controllers.get(controllerOption);
	}

}
