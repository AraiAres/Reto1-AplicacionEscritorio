package com.gymsync.app.controllers;

import java.util.Date;

import com.gymsync.app.model.entities.User;
import com.gymsync.app.repository.firebaseManager.FireBaseManager;

public class SignupPanelController extends AbstractController {
	
	FireBaseManager fbManager = new FireBaseManager();

	public void addNewUserToDB(String name, String lastName, String email, String pass, Date birth) {
		User user = newUser(name, lastName, email, pass, birth);
		fbManager.addUser(user);
	}

	public User newUser(String name, String lastName, String email, String pass, Date birth) {
		User user = new User();
		user.setName(name);
		user.setLastame(lastName);
		user.setEmail(email);
		user.setPassword(pass);
		user.setBirthDate(birth);
		return user;
	}
}
