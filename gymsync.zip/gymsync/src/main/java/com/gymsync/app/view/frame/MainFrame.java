package com.gymsync.app.view.frame;

import java.awt.BorderLayout;
import java.awt.Dimension;
import javax.swing.JFrame;

import com.gymsync.app.config.UIConfig;
import com.gymsync.app.view.PanelFactory;


public class MainFrame extends JFrame{
	
	private static final long serialVersionUID = -5368545434453831333L;

	public MainFrame() {
		initialize();
	}

	public void initialize(){
		setTitle(UIConfig.APP_NAME);
		setResizable(false);
		setSize(new Dimension(1200, 750));
		setLayout(new BorderLayout());
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setLocationRelativeTo(null);

		addPanelsToFrame();

		PanelFactory.getInstance().hideAll();
		PanelFactory.getInstance().show(PanelFactory.panelOptions.LOGIN_PANEL.value);
		
		setVisible(true);
	}
	
	private void addPanelsToFrame() {
		add(PanelFactory.getInstance().getPanel("loginPanel"));
		add(PanelFactory.getInstance().getPanel("signupPanel"));
		add(PanelFactory.getInstance().getPanel("workoutPanel"));
		add(PanelFactory.getInstance().getPanel("profilePanel"));
	}
}
