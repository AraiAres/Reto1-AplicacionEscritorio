package com.gymsync.app.services;

import java.util.HashMap;

public class ServiceFactory {

	private static ServiceFactory instance = null;
	private HashMap<String, AbstractService> services = null;

	public static enum ServiceOptions {
		SIGNUP_PANEL_SERVICE("signupPanelService");

		public final String value;

		private ServiceOptions(String value) {
			this.value = value;
		}
	}

	public ServiceFactory() {
		services = new HashMap<String, AbstractService>();
		services.put(ServiceOptions.SIGNUP_PANEL_SERVICE.value, new SignupPanelService());
	}

	public static ServiceFactory getInstance() {
		return instance = instance == null ? new ServiceFactory() : instance;
	}

	public AbstractService getService(String serviceOption) {
		return services.get(serviceOption);
	}

}
