package com.gymsync.app.view;

import java.util.HashMap;
import com.gymsync.app.view.panels.AbstractPanel;
import com.gymsync.app.view.panels.LoginPanel;
import com.gymsync.app.view.panels.ProfilePanel;
import com.gymsync.app.view.panels.SignupPanel;
import com.gymsync.app.view.panels.WorkoutPanel;

public class PanelFactory {

	private static PanelFactory instance = null;
	private HashMap<String, AbstractPanel> panels = null;

	public static enum panelOptions {
		LOGIN_PANEL("loginPanel"), SIGNUP_PANEL("signupPanel"), WORKOUT_PANEL("workoutPanel"), PROFILE_PANEL("profilePanel");

		public final String value;

		private panelOptions(String value) {
			this.value = value;
		}
	}

	public PanelFactory() {
		panels = new HashMap<String, AbstractPanel>();
		panels.put(panelOptions.LOGIN_PANEL.value, new LoginPanel());
		panels.put(panelOptions.SIGNUP_PANEL.value, new SignupPanel());
		panels.put(panelOptions.WORKOUT_PANEL.value, new WorkoutPanel());
		panels.put(panelOptions.PROFILE_PANEL.value, new ProfilePanel());
	}

	public static PanelFactory getInstance() {
		return instance = instance == null ? new PanelFactory() : instance;
	}

	public AbstractPanel getPanel(String panelOption) {
		return panels.get(panelOption);
	}

	public void hideAll() {
		panels.forEach((key, panel) -> panel.setVisible(false));
	}

	public void showAll() {
		panels.forEach((key, panel) -> panel.setVisible(true));
	}

	public void show(String panelOption) {
		panels.get(panelOption).setVisible(true);
	}

	public void hide(String panelOption) {
		panels.get(panelOption).setVisible(false);
	}

}
