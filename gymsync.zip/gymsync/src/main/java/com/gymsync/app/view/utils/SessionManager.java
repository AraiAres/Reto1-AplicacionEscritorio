package com.gymsync.app.view.utils;

import com.gymsync.app.model.entities.User;

public class SessionManager {
	private static SessionManager instance = null;
	private User currentUser = null;

	public SessionManager() {
	};

	public SessionManager getInstance() {
		if (instance == null) {
			instance = new SessionManager();
		}
		return instance;
	}

	public User getCurrentUser() {
		return currentUser;
	}

	public void setCurrentUser(User user) {
		this.currentUser = user;
	}

	public void logout() {
		currentUser = null;
	}

}
