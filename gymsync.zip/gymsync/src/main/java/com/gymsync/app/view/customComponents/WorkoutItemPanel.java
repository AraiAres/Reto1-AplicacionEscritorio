package com.gymsync.app.view.customComponents;

import javax.swing.JPanel;
import javax.swing.SwingConstants;
import javax.swing.JLabel;
import javax.swing.JButton;
import javax.swing.BorderFactory;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.event.ActionListener;

import com.gymsync.app.config.UIConfig;
import com.gymsync.app.model.entities.Workout;

public class WorkoutItemPanel extends JPanel {

	private static final long serialVersionUID = 1L;

	private JLabel nameLabel = null;
	private JPanel infoPanel = null;
	private JLabel nExercisesLabel;
	private JLabel levelLabel = null;
	private JLabel videoLabel = null;
	private ArrowButton openButton = null;

	public WorkoutItemPanel(Workout workout, ActionListener openWorkoutListener) {

		setPreferredSize(new Dimension(700, 100));
		setMaximumSize(new Dimension(700, 100));
		setBackground(UIConfig.LIGHT_MINT);
		setBorder(BorderFactory.createLineBorder(UIConfig.EMIRALD_DARK, 2));
		setLayout(null);

		nameLabel = new JLabel(workout.getName());
		nameLabel.setBounds(275, 0, 150, 50);
		nameLabel.setFont(UIConfig.WORKOUT_TITLE_FONT);
		nameLabel.setHorizontalAlignment(SwingConstants.CENTER);
		nameLabel.setVerticalAlignment(SwingConstants.CENTER);
		nameLabel.setForeground(UIConfig.EMIRALD_DARK);

		infoPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 30, 0));
		infoPanel.setOpaque(false);
		infoPanel.setBounds(0, 50, 700, 40);

		levelLabel = new JLabel("Nivel: " + workout.getLevel());
		levelLabel.setFont(UIConfig.INPUT_FONT);
		levelLabel.setForeground(UIConfig.EMIRALD);

		nExercisesLabel = new JLabel("Ejercicios: " + workout.getNExcercises());
		nExercisesLabel.setFont(UIConfig.INPUT_FONT);
		nExercisesLabel.setForeground(UIConfig.EMIRALD);

		videoLabel = new JLabel("<html>Video: <a href='#'>" + workout.getUrlVideo() + "</a></html>");
		videoLabel.setFont(UIConfig.INPUT_FONT);
		videoLabel.setForeground(UIConfig.EMIRALD);

		infoPanel.add(levelLabel);
		infoPanel.add(nExercisesLabel);
		infoPanel.add(videoLabel);

		openButton = new ArrowButton(UIConfig.PRIMARY_GRADIENT);
		openButton.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 0, 0));
		openButton.setFont(UIConfig.INPUT_FONT);
		openButton.setBounds(660, 60, 40, 40);
		openButton.addActionListener(openWorkoutListener);

		add(nameLabel);
		add(infoPanel);
		add(openButton);
	}
}
