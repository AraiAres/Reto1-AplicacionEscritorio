package com.gymsync.app.view.panels;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.SwingConstants;

import com.gymsync.app.config.UIConfig;
import com.gymsync.app.view.PanelFactory;

public class ProfilePanel extends AbstractPanel {

	private static final long serialVersionUID = 3685658604197819107L;

	private JLabel title = null;

	private JButton backButton = null;

	public ProfilePanel() {
		initialize();
	}

	@Override
	protected void initialize() {

		title = new JLabel("profile Panel");
		title.setBounds(450, 150, 250, 70);
		title.setHorizontalAlignment(SwingConstants.CENTER);
		title.setVerticalAlignment(SwingConstants.CENTER);
		title.setBorder(BorderFactory.createLineBorder(UIConfig.EMIRALD_DARK, 2));
		title.setForeground(UIConfig.EMIRALD);
		title.setFont(UIConfig.TITLE_FONT);

		backButton = new JButton("back");
		backButton.setBounds(300, 30, 50, 50);
		backButton.setAlignmentX(CENTER_ALIGNMENT);
		backButton.addActionListener(e -> {
			switchToWorkoutPanel();
		});

		add(title);
		add(backButton);
	}

	private void switchToWorkoutPanel() {
		PanelFactory.getInstance().hideAll();
		PanelFactory.getInstance().show("workoutPanel");
	}
}
