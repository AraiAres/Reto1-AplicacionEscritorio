package com.gymsync.app.controllers;

import com.gymsync.app.services.exceptions.LoginException;

public class LoginPanelController extends AbstractController {

	public boolean validateCredentials(String user, char[] pass) throws LoginException {
		String password = new String(pass);
		if (user.equalsIgnoreCase("123") && password.equals("123")) {
			return true;
		} else {
			throw new LoginException("Credenciales inválidas");
		}
	}

}
